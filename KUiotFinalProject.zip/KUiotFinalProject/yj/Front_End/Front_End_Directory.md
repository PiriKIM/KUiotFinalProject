Front_End/
├── app.py                # Flask 서버
├── templates/
│   └── index.html        # 메인 웹페이지
├── static/
│   └── script.js         # 웹캠 캡처 및 통신 JS
└── (필요시) utils/
    └── neck_analyzer.py  # neck.py의 분석 함수만 분리


    